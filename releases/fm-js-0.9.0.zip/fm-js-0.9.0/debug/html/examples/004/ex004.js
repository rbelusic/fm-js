// == create predefined template ==========================================
FM.UtTemplate.addTemplate("predefined.dummy.html",
    "<div>predefined dummy template</div>"
);
