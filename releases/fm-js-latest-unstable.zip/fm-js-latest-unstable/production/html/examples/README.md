List of examples:
[001](https://rawgithub.com/rbelusic/fm-js/master/html/examples/001/index.html) - hosts, observers, events
[002](https://rawgithub.com/rbelusic/fm-js/master/html/examples/002/index.html) - data lists, fetching data from remote
[003](https://rawgithub.com/rbelusic/fm-js/master/html/examples/003/index.html) - data lists, generic collection host (display data in table), 
[004](https://rawgithub.com/rbelusic/fm-js/master/html/examples/004/index.html) - observer Extensions (MlListOfValues),


